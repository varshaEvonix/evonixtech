### 2013-12-13 v0.2.5

* Fixed error with updating lowest column while adding new items.

### 2013-11-24 v0.2.4

* Temporary container never shrunk when resizing viewport (by [raulferras](https://github.com/raulferras)).

### 2013-10-18 v0.2.3

* `recomputeHeights` method (by [vitos555](https://github.com/vitos555)).
* Events (by [matmuchrapna](https://github.com/matmuchrapna)).
* Bug fixes (by [clinisbut](https://github.com/clinisbut) and [vitos555](https://github.com/vitos555)).

### 2013-07-01 v0.2.2

* `empty` method (by [vitos555](https://github.com/vitos555)).
* Bug fixes (by [mvavrecan](https://github.com/mvavrecan), [Sunify](https://github.com/Sunify) and [vitos555](https://github.com/vitos555)).

### 2013-06-05 v0.2.0

* Accepts arbitrary HTML, `add`/`remove` methods (by [clinisbut](https://github.com/clinisbut)).
